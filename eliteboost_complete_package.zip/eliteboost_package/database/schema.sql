CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    whatsapp VARCHAR(20),
    password_hash TEXT NOT NULL,
    role VARCHAR(20) DEFAULT 'member' CHECK (role IN ('member', 'reseller', 'admin')),
    balance NUMERIC(12, 2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS products (
    id SERIAL PRIMARY KEY,
    sku_code VARCHAR(50) UNIQUE NOT NULL,
    category VARCHAR(50) NOT NULL,
    brand VARCHAR(100) NOT NULL,
    product_name VARCHAR(150) NOT NULL,
    base_price NUMERIC(12, 2) NOT NULL,
    reseller_price NUMERIC(12, 2) NOT NULL,
    public_price NUMERIC(12, 2) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_number VARCHAR(30) UNIQUE NOT NULL,
    user_id UUID REFERENCES users(id) NULL,
    buyer_role VARCHAR(20) DEFAULT 'member',
    sku_code VARCHAR(50) NOT NULL,
    target_id VARCHAR(100) NOT NULL,
    base_price NUMERIC(12, 2) NOT NULL,
    selling_price NUMERIC(12, 2) NOT NULL,
    gateway_fee NUMERIC(12, 2) DEFAULT 0,
    net_profit NUMERIC(12, 2) NOT NULL,
    payment_method VARCHAR(30) NOT NULL,
    payment_status VARCHAR(20) DEFAULT 'UNPAID' CHECK (payment_status IN ('UNPAID', 'PAID', 'EXPIRED', 'FAILED')),
    fulfillment_status VARCHAR(20) DEFAULT 'PENDING' CHECK (fulfillment_status IN ('PENDING', 'PROCESSING', 'SUCCESS', 'FAILED')),
    serial_number TEXT NULL,
    provider_response JSONB NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS owner_ledger (
    id SERIAL PRIMARY KEY,
    transaction_id UUID REFERENCES transactions(id),
    profit_amount NUMERIC(12, 2) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);
