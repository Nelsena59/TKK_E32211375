# Paket Iklan Top Up Game — ELITEBOOST

## 1. 3 Opsi Hook Video Pendek
- **Opsi 1 (Kecepatan):** "Lagi di draft pick skin incaran tinggal semenit lagi habis, tapi saldo belum masuk? Top up di sini hitungan detik langsung mendarat."
- **Opsi 2 (Harga Hemat & Aman):** "Ngapain top up mahal kalau dengan budget yang sama bisa dapet diamond lebih banyak, legal, dan anti minus?"
- **Opsi 3 (Tanpa Login):** "Top up game nggak perlu kasih password akun. Cukup masukin ID sama Server, proses otomatis 24 jam nonstop."

## 2. Skrip Video 25–35 Detik
- **00–04 detik (Hook):** Rekam layar lobi game saat event baru muncul -> Narasi: "Event skin baru udah keluar, jangan sampai kelewatan cuma gara-gara proses top up lemot."
- **04–16 detik (Solusi):** Rekam input User ID + Server, pilih nominal, dan metode bayar -> Narasi: "Di ELITEBOOST, top up cukup pakai ID dan Server aja—tanpa login akun, 100% legal dan aman."
- **16–25 detik (Kecepatan):** Tunjukkan notifikasi pembayaran sukses & saldo in-game bertambah -> Narasi: "Proses otomatis 24 jam nonstop, hitungan detik langsung masuk ke akun."
- **25–32 detik (CTA):** Tampilkan daftar harga / link order -> Narasi: "Cek daftar harga lengkapnya sekarang sebelum promo event berakhir!"

## 3. Caption Media Sosial
- **Gaya Santai:** Momen paling nyesek itu pas skin incaran muncul di shop, tapi proses top up muter-muter nggak masuk-masuk. Di ELITEBOOST semua serba sat-set, proses otomatis 24 jam, cukup ID & Server (tanpa login), dan support QRIS serta E-Wallet.
- **Gaya Promo:** TOP UP GAME CEPAT, MURAH & LEGAL 100%! Tersedia Mobile Legends, Free Fire, PUBG Mobile, Valorant, Genshin Impact, Roblox, serta pulsa, paket data, dan token PLN.

## 4. Teks Broadcast WhatsApp
Halo Gamers! Lagi kejar event skin atau pass bulan ini? Top up di ELITEBOOST aja: proses otomatis 24 jam, 100% legal (cukup ID & Server), dan pembayaran praktis via QRIS/E-Wallet. Balas pesan ini untuk cek daftar harga game favoritmu!
