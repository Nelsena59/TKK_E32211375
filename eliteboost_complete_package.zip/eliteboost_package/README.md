# ELITEBOOST — Paket Lengkap Dalam 1 Folder

Folder ini menyatukan seluruh materi yang telah dibuat:
- `frontend/index.html` — Antarmuka web ELITEBOOST (katalog game & PPOB, mode harga umum vs reseller, kalkulasi margin profit, riwayat transaksi/SN, dan widget CS AI).
- `backend/server.js`, `backend/package.json`, `backend/.env.example` — Backend Express + PostgreSQL untuk pemrosesan order, webhook pembayaran, pengiriman top up H2H, dan pencatatan profit bersih owner.
- `database/schema.sql` — Skema tabel PostgreSQL (`users`, `products`, `transactions`, `owner_ledger`).
- `prompts_and_ads/system_prompt_konten_jualan.md` — System prompt asisten konten & copywriting jualan.
- `prompts_and_ads/iklan_topup_game.md` — Naskah hook, skrip video, caption, dan broadcast WA promosi top up game.
